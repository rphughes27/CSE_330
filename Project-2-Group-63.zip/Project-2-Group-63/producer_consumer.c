#include <linux/module.h>
#include <linux/kernel.h> // KERN_INFO
#include <linux/moduleparam.h>
#include <linux/kthread.h>
#include <linux/sched.h>
#include <linux/sched/signal.h>
#include <linux/semaphore.h>
#include <linux/timekeeping.h>
#include <linux/mutex.h>
#include <linux/time.h>

/* module parameter for buffSize */
static int buffSize = 0;
module_param(buffSize, int, 0644);
MODULE_PARM_DESC(buffSize, "Buffer size");

/* module parameter for prod */
static int prod = 0;
module_param(prod, int, 0644);
MODULE_PARM_DESC(buffSize, "Number of producers");

/* module parameter for cons */
static int cons = 0;
module_param(cons, int, 0644);
MODULE_PARM_DESC(cons, "Number of consumers");

/* module parameter for uuid */
static int uuid = 1000;
module_param(uuid, int, 0644);
MODULE_PARM_DESC(uuid, "UID of the user");

#define buffSize2 1000
struct task_struct *p;
struct mutex mutex;
struct semaphore empty;
struct semaphore full;


static struct task_struct *thread1; 
static struct task_struct *thread2;
static struct task_struct *thread3;

int buffer[buffSize2];
int in = 0;
int out = 0;
int bufferIndex = 0;
int i = 0;


struct task_struct *p;
size_t process_counter = 0;
ktime_t total_time = 0;

static int kthread_funcP(void *arg) // Producer thread
{ 
	for_each_process(p)
	{

		if (p->cred->uid.val == uuid)
		{
			down(&empty);
			mutex_lock(&mutex);
			buffer[in] = p->pid;
			bufferIndex = in;
			in++;
			mutex_unlock(&mutex);
			up(&full);	
			++process_counter;
			printk("%s Produced item# %lu on buffer index: %d PID:%d ", current->comm , process_counter, bufferIndex, p->pid);
		}
		
	}
	return 0;
}

static int kthread_funcC(void *arg) // Consumer threads
{ 
	int items_consumed = 0;
	ktime_t seconds = 0;
	while (!kthread_should_stop())
	{

		down(&full);
		mutex_lock(&mutex);	
		p->pid = buffer[in];
		bufferIndex = in;
		in--;
		seconds = (ktime_get_ns() - p->start_time) / 1000000000;
		total_time+=seconds;
		mutex_unlock(&mutex);
		up(&empty);
		++items_consumed;
		printk("%s Consumed item# %d on buffer index: %d PID:%d Elapsed time %llu", current->comm , items_consumed, bufferIndex, p->pid, seconds);	
	
	}
	return 0;
}

static int initialize(void)
{
	printk(KERN_INFO "Hello from initialize\n");
	printk(KERN_INFO "Value of [buffSize] at init = %d\n", buffSize);
	printk(KERN_INFO "Value of [prod] at init = %d\n", prod);
	printk(KERN_INFO "Value of [cons] at init = %d\n", cons);
	printk(KERN_INFO "Value of [uuid] at init = %d\n", uuid);

	sema_init(&empty, buffSize);
	sema_init(&full,  0);
	mutex_init(&mutex);
	if (prod == 1)
	{
		thread1 = kthread_run(kthread_funcP, NULL, "Producer");
	}
	if(cons == 0)
	{
	} else if (cons == 1)
	{
	thread2 = kthread_run(kthread_funcC, NULL, "Consumer");
	} else if (cons == 2)
	{
	thread2 = kthread_run(kthread_funcC, NULL, "Consumer");
	thread3 = kthread_run(kthread_funcC, NULL, "Consumer2");
	}
	return 0;
}

static void clean_exit(void)
{
	printk(KERN_INFO "Goodbye from clean_exit\n");
	printk(KERN_INFO "Value of [buffSize] at exit = %d\n", buffSize);
	printk(KERN_INFO "Value of [prod] at exit = %d\n", prod);
	printk(KERN_INFO "Value of [cons] at exit = %d\n", cons);
	printk(KERN_INFO "Value of [uuid] at exit = %d\n", uuid);
	printk(KERN_INFO "Total time elapsed in seconds:  %llu\n" ,total_time);
	
	
}

module_init(initialize);
module_exit(clean_exit);
MODULE_LICENSE("GPL"); // defines license of the module
// MODULE_DESCRIPTION("producer_consumer Module");
// MODULE_AUTHOR("SGG");
