a. Group 63
   Cristine Zambrano Ortega
   David Soto
   Jeffrey LaFleur
   Ryan Hughes


b. Let us know if you would like to see a demo
   or if you would like access to our private Github!
   Apart from the resources listed on the document, we
   also used this resource for help with building the 
   system call: 
   https://redirect.cs.umbc.edu/courses/undergraduate/421/spring21/docs/project0.html
   
   Our 4 screenshots are in the 'Screenshots of Outputs' folder
   and our code is in the 'Source Code' folder